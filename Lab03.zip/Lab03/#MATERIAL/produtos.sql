TRUNCATE clientes












