<div class="container-fluid">
    <div class="row">
        <div class="col-12">

        <h1>Página inicial da loja</h1>

        <a href="http://localhost/Lab03/entrada%20login.html" class="btn btn-primary btn-100">Clique no botão para voltar à página principal</a>
    <br><br><br><br><br><br><br><br><br><br>
        </div>
    </div>
</div>