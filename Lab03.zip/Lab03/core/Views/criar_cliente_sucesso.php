<div class="container">
    <div class="row my-5">
        <div class="col-sm-6 offset-sm-3">
            <h3 class="text-center">Novo cliente criado com sucesso</h3>
            <p>Foi enviado um email com o link para confirmação da sua conta.</p>
            <p>Por favor verifique se o email aparece na sua conta ou se foi para a pasta do SPAM.</p>
            <div class="my-5"><a href="?a=inicio" class="btn btn-primary">Voltar</a></div>
        </div>
    </div>
</div>