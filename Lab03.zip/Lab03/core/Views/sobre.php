<div class="container espaco-fundo">

    <!-- titulo da página -->
    <div class="row">
        <div class="col-12 my-4">

<h2>Sobre</h2>

Little Bricks é uma loja, de momento, apenas online que oferece uma vasta gama de produtos para toda a gente, desde legos para crianças até legos para adultos.
<br>
Gostamos de tratar os nossos clientes como gostávamos que nos tratassem, como tal estamos sempre disponíveis para esclarecer qualquer dúvida ou qualquer informação.
<br><br><br><br><br>
</div>
</div>
</div>