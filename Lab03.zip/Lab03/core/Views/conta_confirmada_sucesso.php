<div class="container">
    <div class="row my-5">
        <div class="col-sm-6 offset-sm-3">
            <h3 class="text-center">Conta confirmada com sucesso</h3>
            <p>A sua conta de cliente foi confirmada. Seja bem-vindo à nossa loja.</p>
            <div class="my-5"><a href="?a=login" class="btn btn-primary">Login</a></div>
        </div>
    </div>
</div>