<div class="container-fluid rodape p-3">
    <div class="row justify-content-center align-items-center">
        <div class="col-1 p-8 text-center">
            <a href="?a=perfil" class="nav-item2">A minha conta</a>
            <a href="?a=carrinho" class="nav-item2">Carrinho</a>
            <a href="?a=carrinho" class="nav-item2">Checkout</a>
        </div>
        <div class="col-2 p-3 text-center">
            <img src="assets/images/logobrick.png" alt="Minha Imagem" width="150" height="150">
        </div>
        <div class="col-1 p-8 text-center">
            <a href="?a=loja" class="nav-item2">Loja Online</a>
            <a href="?a=sobre" class="nav-item2">Sobre Nós</a>
            <a href="?a=contactos" class="nav-item2">Contactos</a>
        </div>
    </div>
    <div class="col-9 d-flex justify-content-end">
        <i class="fab fa-facebook" style="color: #ffffff; margin-right: 10px;"></i>
        <i class="fab fa-instagram" style="color: #ffffff;"></i> 
    </div>
    <div class="row">
    <div class="col-10 p-3" style="margin-left: 300px;">
        <div class="col-9 text-end">        
            <a href="?a=termos" class="nav-item2">Termos e Condições</a>
            <a href="?a=politica" class="nav-item2">Política de Privacidade</a>
            <a href="https://www.livroreclamacoes.pt/INICIO/" class="nav-item2">Livro de Reclamações</a>
        </div>
        <small><?= APP_NAME .' &copy; ' . date('Y')?></small><br>
        <small>Criação de Website: David Gomes e Karina Trompak</small>
    </div>
</div>

</div>
