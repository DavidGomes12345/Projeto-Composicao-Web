<div class="container">
    <div class="row my-5">
        <div class="col-sm-6 offset-sm-3">
            <h3 class="text-center">Foi preenchido com sucesso</h3>
            <p>Assim que seja possível iremos responder e ajudar no que for possível!</p>
            <p>Obrigado!</p>
            <div class="my-5"><a href="?a=inicio" class="btn btn-primary">Voltar</a></div>
        </div>
    </div>
</div>