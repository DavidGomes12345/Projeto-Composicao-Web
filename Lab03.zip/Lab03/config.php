<?php

define('APP_NAME',          'Little Bricks');
define('APP_VERSION',       '1.0.0');

define('BASE_URL',          'http://localhost/Lab03/public/');

// MYSQL
define('MYSQL_SERVER',      'localhost');
define('MYSQL_DATABASE',    'store');
define('MYSQL_USER',        'user_php_store');
define('MYSQL_PASS',        'du538On8');
define('MYSQL_CHARSET',     'utf8');

// mail
define('EMAIL_HOST',        'smtp.gmail.com');
define('EMAIL_FROM',        'david32534@esfundao.pt');
define('EMAIL_PASS',        'sqsWO192');
define('EMAIL_PORT',        587);


// AES encriptação
define('AES_KEY',           'qs8BzdLD8N7qJgqJ3qmGsuh8HMhCWqG4');
define('AES_IV',            'WSzH6HcdZAYdQ9be');


define("STATUS", ["PENDENTE","EM PROCESSAMENTO","ENVIADA","CANCELADA","CONCLUIDA"]);